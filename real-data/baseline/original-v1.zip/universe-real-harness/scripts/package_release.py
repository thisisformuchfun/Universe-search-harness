"""Build a source ZIP; no caches, credentials, old runs, binaries or model weights."""
from pathlib import Path
import zipfile,hashlib
root=Path(__file__).resolve().parents[1]
out=root.parent/'Universe_Search_Harness_Real_Data_v1.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(root.rglob('*')):
        if not p.is_file() or p.is_symlink():continue
        rel=p.relative_to(root)
        if any(x.startswith('.') or x=='__pycache__' or x.endswith('.egg-info') for x in rel.parts):continue
        if rel.parts[:2]==('data','cache'):continue
        if rel.parts[0]=='runs' and not (rel.parts[1]=='verified-release' or rel.name in {'test-results.txt','live_connector_probe.json','live_post_probe.json','release-console.json'}):continue
        z.write(p,Path(root.name)/rel)
print(out)
print('SHA256',hashlib.sha256(out.read_bytes()).hexdigest())
print('Bytes',out.stat().st_size)
