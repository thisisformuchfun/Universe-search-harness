"""Synthetic protocol fixtures only; never production observations."""
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from harness2.universe.connectors.public_archives import (
 PublicSkyConnector, ArchiveError, parse_votable, _safe_id, _check_composite_duplicates,
 load_csv_snapshot, sha256, GAIA_TAP, _validate_endpoint)

ID='5991734159714775296'
def votable(rows=None,status='OK',tail=''):
 rows=rows if rows is not None else [(ID,'Orbital')]
 body=''.join('<TR><TD>'+sid+'</TD><TD>'+kind+'</TD></TR>' for sid,kind in rows)
 return (f'<VOTABLE><RESOURCE><INFO name="QUERY_STATUS" value="{status}"/>'
 '<TABLE><FIELD name="source_id" datatype="long"/><FIELD name="nss_solution_type" datatype="char" arraysize="*"/>'
 f'<DATA><TABLEDATA>{body}</TABLEDATA></DATA></TABLE>{tail}</RESOURCE></VOTABLE>').encode()

class ConnectorTests(unittest.TestCase):
 def test_ids_exact(self):
  self.assertEqual(parse_votable(votable())[0]['source_id'],ID)
  for bad in [float(ID),True,'5.99e18','1.0','-1','0']:
   with self.assertRaises(ArchiveError):_safe_id(bad)
 def test_error_overflow(self):
  for status in ['ERROR','OVERFLOW','UNKNOWN']:
   with self.assertRaises(ArchiveError):parse_votable(votable(status=status))
  with self.assertRaises(ArchiveError):parse_votable(votable(tail='<INFO name="QUERY_STATUS" value="OVERFLOW"/>'))
 def test_truncation_html_binary(self):
  for raw in [votable()[:-10],b'<html>error</html>',b'<VOTABLE/>',votable().replace(b'TABLEDATA',b'BINARY')]:
   with self.assertRaises(ArchiveError):parse_votable(raw)
 def test_schema_and_entities(self):
  with self.assertRaises(ArchiveError):parse_votable(votable(),('missing',))
  with self.assertRaises(ArchiveError):parse_votable(b'<!DOCTYPE x>'+votable())
 def test_array(self):
  raw=b'<VOTABLE><RESOURCE><INFO name="QUERY_STATUS" value="OK"/><TABLE><FIELD name="corr_vec" datatype="float" arraysize="*"/><DATA><TABLEDATA><TR><TD>0.1 -0.2 NaN</TD></TR></TABLEDATA></DATA></TABLE></RESOURCE></VOTABLE>'
  self.assertEqual(parse_votable(raw)[0]['corr_vec'],[0.1,-0.2,None])
 def test_distinct_solutions_preserved(self):
  rows=parse_votable(votable([(ID,'Orbital'),(ID,'AstroSpectroSB1')]))
  _check_composite_duplicates(rows)
  with self.assertRaises(ArchiveError):_check_composite_duplicates(rows+rows[:1])
 def test_endpoint_allowlist(self):
  for url in ['http://gea.esac.esa.int/a','https://evil.test/','https://user:pass@gea.esac.esa.int/a','https://gea.esac.esa.int:8443/a']:
   with self.assertRaises(ArchiveError):_validate_endpoint(url)
 def test_cache_explicit_and_tamper(self):
  with tempfile.TemporaryDirectory() as d:
   c=PublicSkyConnector(d)
   with patch.object(c,'_request',return_value=(votable(),{'http_status':200})) as request:
    r=c.tap(GAIA_TAP,'SELECT TOP 1 source_id FROM x',2)
    self.assertFalse(r.provenance['cache_reused'])
    self.assertTrue(c.tap(GAIA_TAP,'SELECT TOP 1 source_id FROM x',2,offline=True).provenance['cache_reused'])
    self.assertEqual(request.call_count,1)
   with patch.object(c,'_request',side_effect=ArchiveError('offline')):
    with self.assertRaises(ArchiveError):c.tap(GAIA_TAP,'SELECT TOP 1 source_id FROM x',2)
   next(Path(d).glob('*.xml')).write_bytes(votable([(ID,'Other')]))
   with self.assertRaises(ArchiveError):c.tap(GAIA_TAP,'SELECT TOP 1 source_id FROM x',2,offline=True)
 def test_cache_keeps_prior_live_versions(self):
  with tempfile.TemporaryDirectory() as d:
   c=PublicSkyConnector(d);q='SELECT TOP 1 source_id FROM x'
   with patch.object(c,'_request',side_effect=[(votable([(ID,'Orbital')]),{'http_status':200}),(votable([(ID,'Other')]),{'http_status':200})]):
    first=c.tap(GAIA_TAP,q,2);c.tap(GAIA_TAP,q,2)
   old=c.tap(GAIA_TAP,q,2,offline=True,expected_sha256=first.provenance['raw_sha256'])
   self.assertEqual(old.rows[0]['nss_solution_type'],'Orbital')
   self.assertEqual(c.tap(GAIA_TAP,q,2,offline=True).rows[0]['nss_solution_type'],'Other')
 def test_snapshot_hash(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'a.csv';p.write_text('source_id,nss_solution_type\n'+ID+',Orbital\n')
   self.assertEqual(load_csv_snapshot(p,sha256(p.read_bytes()),('source_id',))[0]['source_id'],ID)
   with self.assertRaises(ArchiveError):load_csv_snapshot(p,'bad',('source_id',))
 def test_keyset_query(self):
  q=PublicSkyConnector.nss_query(10,(ID,'Orbital'))
  self.assertIn("source_id = "+ID+" AND nss_solution_type > 'Orbital'",q)
  self.assertIn('corr_vec',q)
  with self.assertRaises(ArchiveError):PublicSkyConnector.nss_query(10,(ID,"x' OR 1=1"))
 def test_pagination_resume(self):
  with tempfile.TemporaryDirectory() as d:
   c=PublicSkyConnector(Path(d)/'cache')
   pages=[votable([('10','AstroSpectroSB1'),('10','Orbital')]),votable([('11','Orbital')])]
   with patch.object(c,'_request',side_effect=[(p,{'http_status':200}) for p in pages]):
    # Required schema is separately exercised; this protocol fixture has only keys.
    with patch('harness2.universe.connectors.public_archives.NSS_REQUIRED',frozenset({'source_id','nss_solution_type'})):
     r=c.gaia_nss_pages(Path(d)/'run',page_size=2,max_pages=1)
     self.assertFalse(r.provenance['complete']);self.assertEqual(len(r.rows),2)
     r=c.gaia_nss_pages(Path(d)/'run',page_size=2,max_pages=2,resume=True)
     self.assertTrue(r.provenance['complete']);self.assertEqual(len(r.rows),3)
     with self.assertRaises(ArchiveError):c.gaia_nss_pages(Path(d)/'run',page_size=3,max_pages=2,resume=True)

if __name__=='__main__':unittest.main()
