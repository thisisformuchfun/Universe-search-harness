"""Independent boundary tests. Fabricated configurations are tests, not sky data."""
import hashlib
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from harness2.core.components import HarnessBundle
from harness2.core.library import ContinualLibrary
from harness2.core.recursion import Harness2Engine
from harness2.core import guards
from harness2.providers.router import LLMConfig, UniversalModelRouter

BASE = dict(mass_function_weight=1, precision_weight=1, efficiency_weight=1)

class BoundaryTests(unittest.TestCase):
    def test_invalid_proposals(self):
        for value in [float('nan'), float('inf'), -1, True, '2', 5]:
            with self.subTest(value=repr(value)), self.assertRaises(ValueError):
                HarnessBundle.from_dict({**BASE, 'precision_weight': value})
        with self.assertRaises(ValueError):
            HarnessBundle.from_dict({**BASE, 'release_enabled': True})
        with self.assertRaises(ValueError):
            HarnessBundle.from_dict({key: 0 for key in BASE})

    def test_remote_and_credentialed_proposer_rejected(self):
        for url in ['http://evil.test/v1', 'https://127.0.0.1.evil.test/v1',
                    'http://user:pass@127.0.0.1/v1', 'http://127.0.0.1/v1?url=x']:
            with self.subTest(url=url), self.assertRaises(ValueError):
                UniversalModelRouter(LLMConfig('local', 'test-only', url))
        with self.assertRaises(ValueError):
            UniversalModelRouter(LLMConfig('remote', 'test-only'))

    def test_local_failure_does_not_fallback(self):
        router = UniversalModelRouter(LLMConfig('local', 'test-only'))
        with patch('urllib.request.OpenerDirector.open', side_effect=TimeoutError('test-only')):
            with self.assertRaises(TimeoutError):
                router.propose(HarnessBundle(), {'count': 0}, 0)

    def test_memory_policy_mismatch_and_injected_fields(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'memory.json'
            library = ContinualLibrary(path)
            library.save(HarnessBundle(), 'old', {})
            with self.assertRaises(ValueError):
                library.load('new')
            data = json.loads(path.read_text())
            data['accepted_configuration']['release_enabled'] = True
            path.write_text(json.dumps(data))
            with self.assertRaises(ValueError):
                library.load('old')

    def test_invalid_review_budgets(self):
        engine = Harness2Engine(None, None)
        for budget in [0, -1, 1001]:
            with self.subTest(budget=budget), self.assertRaises(ValueError):
                engine.run_task([], budget=budget)

    def test_guard_rejects_changed_file_and_symlink(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root/'policy').mkdir()
            target = root/'protected.py'
            target.write_text('original')
            digest = hashlib.sha256(target.read_bytes()).hexdigest()
            (root/'policy/guard_manifest.json').write_text(json.dumps({'files': {'protected.py': digest}}))
            with patch.object(guards, 'ROOT', root):
                guards.verify_guard()
                target.write_text('modified')
                with self.assertRaises(RuntimeError):
                    guards.verify_guard()
                target.unlink()
                sibling = root/'same_content.py'; sibling.write_text('original')
                target.symlink_to(sibling)
                with self.assertRaises(RuntimeError):
                    guards.verify_guard()

if __name__ == '__main__':
    unittest.main()
