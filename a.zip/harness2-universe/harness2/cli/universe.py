"""
`harness2-universe`: Main CLI to run recursive open-sky discovery sweeps using
OpenRouter, any cloud AI API, or any local AI API (Ollama / vLLM / LM Studio).
"""

import argparse
from dataclasses import asdict
import json
from pathlib import Path
from harness2.core.library import ContinualLibrary
from harness2.core.recursion import Harness2Engine
from harness2.providers.router import LLMConfig, UniversalModelRouter
from harness2.universe.connectors.public_archives import PublicSkyConnector


def run_universe_sweep(
    output_dir: Path,
    k: int = 2,
    mode: str = "parallel",
    provider: str = "deterministic",
    model: str = "google/gemini-2.5-pro",
):
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    config = LLMConfig.from_env(provider_override=provider, model_override=model)
    router = UniversalModelRouter(config)
    library = ContinualLibrary(output_dir / "continual_library.json")
    connector = PublicSkyConnector()
    engine = Harness2Engine(router=router, library=library)

    tasks = connector.load_calibrated_benchmark_stream(seed=42)
    results = []
    for task in tasks:
        res = engine.run_task(task, k=k, mode=mode)
        results.append(asdict(res))

    summary = {
        "framework": "Harness2-Universe (built on google-research/harness2)",
        "provider": config.provider,
        "model": config.model,
        "recursion_mode": mode,
        "recursion_budget_k": k,
        "tasks_completed": len(results),
        "base_detections": sum(1 for r in results if r["base_detected"]),
        "refined_detections": sum(1 for r in results if r["final_detected"]),
        "mean_base_snr": round(sum(r["base_snr"] for r in results) / len(results), 2),
        "mean_final_snr": round(sum(r["final_snr"] for r in results) / len(results), 2),
        "results": results,
    }
    (output_dir / "universe_discovery_catalog.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8"
    )
    return summary


def main():
    parser = argparse.ArgumentParser(description="Harness²-Universe Recursive Sky Discovery System")
    parser.add_argument("--output", default="runs/universe_sweep", help="Output directory for catalog & traces")
    parser.add_argument("--k", type=int, default=2, help="Task-level Propose-Probe-Compose recursion budget K")
    parser.add_argument("--mode", choices=["parallel", "sequential"], default="parallel", help="Recursion scaling mode")
    parser.add_argument("--provider", default="deterministic", help="openrouter | local | openai_compatible | gemini | anthropic | deterministic")
    parser.add_argument("--model", default="google/gemini-2.5-pro", help="Model identifier for OpenRouter / Local / Cloud API")
    args = parser.parse_args()

    summary = run_universe_sweep(
        output_dir=Path(args.output),
        k=args.k,
        mode=args.mode,
        provider=args.provider,
        model=args.model,
    )
    print(f"[Harness²-Universe] Completed {summary['tasks_completed']} sky sectors (mode={args.mode}, k={args.k})")
    print(f"  Base Detections: {summary['base_detections']}/{summary['tasks_completed']} (Mean SNR: {summary['mean_base_snr']})")
    print(f"  Refined Detections: {summary['refined_detections']}/{summary['tasks_completed']} (Mean SNR: {summary['mean_final_snr']})")
    for r in summary["results"]:
        status = "DISCOVERED" if r["final_detected"] else "MISSED"
        print(f"  - [{status}] {r['task_id']} ({r['target_name']}): SNR {r['base_snr']} -> {r['final_snr']} (+{r['snr_improvement']})")


if __name__ == "__main__":
    main()
