"""Harness² CLI module `setup` integrated with Universe Discovery benchmarks."""
import sys
from harness2.cli.universe import main as universe_main

def main():
    print("[Harness²-setup] Routing to Harness²-Universe Engine...")
    return universe_main()

if __name__ == "__main__":
    sys.exit(main())
