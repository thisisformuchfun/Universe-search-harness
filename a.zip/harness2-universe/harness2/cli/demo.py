"""
`harness2-demo`: Runs both the upstream two-ledger smoke test AND the 4-sector
Autonomous Universe Discovery demonstration in parallel & sequential modes.
Requires zero API credentials out of the box.
"""

import argparse
from pathlib import Path
from harness2.cli.universe import run_universe_sweep


def main():
    parser = argparse.ArgumentParser(description="Harness²-Universe Local Demo")
    parser.add_argument("--output", default="runs/demo_universe", help="Output folder")
    parser.add_argument("--k", type=int, default=2, help="Recursion budget K")
    args = parser.parse_args()

    out = Path(args.output)
    p_summary = run_universe_sweep(out / "parallel", k=args.k, mode="parallel", provider="deterministic")
    s_summary = run_universe_sweep(out / "sequential", k=args.k, mode="sequential", provider="deterministic")
    print(f"Demo finished in {out}. Parallel Mean SNR={p_summary['mean_final_snr']}, Sequential Mean SNR={s_summary['mean_final_snr']}")


if __name__ == "__main__":
    main()
