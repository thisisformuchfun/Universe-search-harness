"""
The 8 Editable Harness Components defined by Google Research's Harness²:
1. system_prompt
2. guardrails
3. memory
4. tool_guidance
5. subagents
6. skills
7. scripts
8. plugins
"""

from dataclasses import dataclass, field, asdict
from typing import Dict, Any
import copy
import hashlib
import json


@dataclass
class HarnessComponent:
    name: str
    role: str
    content: str
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class HarnessBundle:
    """Represents the complete 8-component execution harness around a frozen model."""
    harness_id: str
    domain: str
    system_prompt: str
    guardrails: str
    memory: str
    tool_guidance: str
    subagents: Dict[str, str]
    skills: Dict[str, str]
    scripts: Dict[str, Dict[str, Any]]
    plugins: Dict[str, str]
    parent_id: str = "root"
    edit_rationale: str = "Initial base harness"

    def clone(self, new_id: str, rationale: str) -> "HarnessBundle":
        copied = copy.deepcopy(self)
        copied.parent_id = self.harness_id
        copied.harness_id = new_id
        copied.edit_rationale = rationale
        return copied

    def fingerprint(self) -> str:
        payload = json.dumps(asdict(self), sort_keys=True)
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()[:12]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
