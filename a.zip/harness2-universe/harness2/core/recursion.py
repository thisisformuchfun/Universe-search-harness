"""
Core Harness² Two-Level Recursive Self-Improvement Engine:
- Level 1 (Task-Level Recursion): Contrastive Propose -> Probe -> Compose loop
  (scales via `--mode parallel` or `--mode sequential` and budget `--k K`).
  Selects & composes harness refinements using behavioral contrasts (whitened residual RMS,
  autocorrelation leakage, phase coherence, and SNR stability) WITHOUT ground-truth labels.
- Level 2 (Harnessing-Level Recursion): Extracts generalizable astrophysical signal-processing
  lessons and updates the persistent ContinualLibrary for downstream sky sectors.
"""

from dataclasses import dataclass, asdict
from typing import List, Dict, Any
from harness2.core.components import HarnessBundle
from harness2.core.library import ContinualLibrary, LessonEntry
from harness2.providers.router import UniversalModelRouter
from harness2.universe.connectors.public_archives import SkySectorTask
from harness2.universe.detectors.signal_pipeline import execute_harness_on_sky_task, DetectionReport
import time


@dataclass
class ContrastiveTrace:
    step_index: int
    mode: str
    base_report: Dict[str, Any]
    general_probe_report: Dict[str, Any]
    domain_probe_report: Dict[str, Any]
    composed_report: Dict[str, Any]
    contrastive_rationale: str


@dataclass
class TaskResult:
    task_id: str
    target_name: str
    domain: str
    archive_source: str
    archive_url: str
    coordinates_ra_dec: str
    mode: str
    recursion_budget_k: int
    base_snr: float
    final_snr: float
    snr_improvement: float
    base_detected: bool
    final_detected: bool
    recovered_parameter: float
    recovered_amplitude: float
    ground_truth_verification: Dict[str, Any]
    adopted_harness_id: str
    prior_lessons_loaded: int
    traces: List[ContrastiveTrace]


def create_base_universe_harness(domain: str) -> HarnessBundle:
    return HarnessBundle(
        harness_id=f"base-{domain}-v0",
        domain=domain,
        system_prompt=(
            "You are an autonomous astrophysical discovery agent operating inside Harness²-Universe. "
            "Inspect sky survey photometry, astrometry, and gravitational-wave strain series to uncover missed objects."
        ),
        guardrails=(
            "Reject instrumental artifacts, seasonal spacecraft thermal roll, and false-alarm spikes (FAP > 1e-3). "
            "Never consult external ground-truth catalogs during online Propose-Probe-Compose refinement."
        ),
        memory="No prior sky-sector lessons loaded yet.",
        tool_guidance="Run the baseline linear detrender and standard single-harmonic periodogram/burst scanner.",
        subagents={
            "detrender_subagent": "Fits a global 1st-order polynomial trend.",
            "periodogram_subagent": "Runs standard single-frequency box/sinusoid scan.",
        },
        skills={
            "tap_adql_skill": "Constructs ADQL queries for NASA Exoplanet Archive and ESA Gaia DR3.",
        },
        scripts={
            "detector_config": {
                "detrend_mode": "naive_linear",
                "outlier_clip_sigma": 99.0,
                "harmonic_orders": 1,
                "matched_template_bank": False,
                "asymmetric_skew_kernel": False,
            }
        },
        plugins={"archive_cache": "enabled"},
    )


class Harness2Engine:
    def __init__(self, router: UniversalModelRouter, library: ContinualLibrary):
        self.router = router
        self.library = library

    def run_task(self, task: SkySectorTask, k: int = 2, mode: str = "parallel") -> TaskResult:
        prior_lessons = self.library.get_domain_lessons(task.domain)
        current_harness = create_base_universe_harness(task.domain)
        if prior_lessons:
            current_harness.memory = "; ".join(
                [f"[{l.lesson_id}] {l.rule_learned} (+{l.snr_gain:.1f} SNR)" for l in prior_lessons]
            )

        base_report = execute_harness_on_sky_task(current_harness, task)
        best_report = base_report
        best_harness = current_harness
        traces: List[ContrastiveTrace] = []

        for step in range(1, k + 1):
            # 1. PROPOSE: Generate 1 General Edit Candidate + 1 Domain-Specific Edit Candidate
            gen_candidate = self._propose_general_candidate(best_harness, best_report, step)
            dom_candidate = self._propose_domain_candidate(best_harness, best_report, task.domain, step)

            # 2. PROBE: Execute both candidate harnesses on the exact same unseen task
            gen_report = execute_harness_on_sky_task(gen_candidate, task)
            dom_report = execute_harness_on_sky_task(dom_candidate, task)

            # 3. COMPOSE: Synthesize behavioral contrasts into a refined harness without ground-truth answers
            composed_harness, rationale = self._compose_from_contrasts(
                best_harness, gen_candidate, dom_candidate,
                best_report, gen_report, dom_report, task.domain, step
            )
            composed_report = execute_harness_on_sky_task(composed_harness, task)

            traces.append(ContrastiveTrace(
                step_index=step,
                mode=mode,
                base_report=best_report.to_dict(),
                general_probe_report=gen_report.to_dict(),
                domain_probe_report=dom_report.to_dict(),
                composed_report=composed_report.to_dict(),
                contrastive_rationale=rationale,
            ))

            # Select best candidate using behavioral evidence (phase coherence & whitened SNR)
            candidates = [
                (best_report, best_harness),
                (gen_report, gen_candidate),
                (dom_report, dom_candidate),
                (composed_report, composed_harness),
            ]
            candidates.sort(key=lambda pair: (pair[0].phase_coherence_score, pair[0].snr), reverse=True)
            best_report, best_harness = candidates[0]

        # Level-2 Harnessing-Level Recursion: Persist lesson to ContinualLibrary
        snr_gain = round(best_report.snr - base_report.snr, 2)
        lesson = LessonEntry(
            lesson_id=f"lesson-{task.task_id}-{mode}",
            task_id=task.task_id,
            domain=task.domain,
            component_edited="scripts.detector_config + tool_guidance + guardrails",
            contrastive_finding=(
                f"Red-noise autocorrelation dropped from {base_report.behavioral_diagnostics['autocorrelation_leakage']} "
                f"to {best_report.behavioral_diagnostics['autocorrelation_leakage']} while SNR rose from {base_report.snr} to {best_report.snr}."
            ),
            rule_learned=best_harness.edit_rationale,
            snr_gain=snr_gain,
            adopted_harness_id=best_harness.harness_id,
            timestamp=time.time(),
        )
        self.library.add_lesson(lesson)

        return TaskResult(
            task_id=task.task_id,
            target_name=task.target_name,
            domain=task.domain,
            archive_source=task.archive_source,
            archive_url=task.archive_url,
            coordinates_ra_dec=task.coordinates_ra_dec,
            mode=mode,
            recursion_budget_k=k,
            base_snr=base_report.snr,
            final_snr=best_report.snr,
            snr_improvement=snr_gain,
            base_detected=base_report.candidate_detected,
            final_detected=best_report.candidate_detected,
            recovered_parameter=best_report.recovered_period_or_epoch,
            recovered_amplitude=best_report.recovered_amplitude,
            ground_truth_verification=task.injected_or_hidden_truth,
            adopted_harness_id=best_harness.harness_id,
            prior_lessons_loaded=len(prior_lessons),
            traces=traces,
        )

    def _propose_general_candidate(self, base: HarnessBundle, report: DetectionReport, step: int) -> HarnessBundle:
        fallback = {
            "detrend_mode": "broad_savgol",
            "outlier_clip_sigma": 3.5,
            "rationale": "General Edit: Add 3.5-sigma robust MAD outlier clipping and Savitzky-Golay continuum filtering.",
        }
        llm_out = self.router.complete_json(
            system_prompt="You are the Harness² General Proposer. Propose a domain-agnostic signal conditioning edit in JSON.",
            user_prompt=f"Diagnostics: {report.behavioral_diagnostics}, SNR={report.snr}",
            fallback_payload=fallback,
        )
        cand = base.clone(
            new_id=f"{base.domain}-gen-k{step}",
            rationale=llm_out.get("rationale", fallback["rationale"]),
        )
        cand.scripts["detector_config"]["detrend_mode"] = llm_out.get("detrend_mode", "broad_savgol")
        cand.scripts["detector_config"]["outlier_clip_sigma"] = float(llm_out.get("outlier_clip_sigma", 3.5))
        return cand

    def _propose_domain_candidate(self, base: HarnessBundle, report: DetectionReport, domain: str, step: int) -> HarnessBundle:
        domain_presets = {
            "exoplanet_transit": {
                "detrend_mode": "adaptive_notch_savgol",
                "matched_template_bank": True,
                "rationale": "Domain Edit (Exoplanet): Apply median-notched rotation detrending + limb-darkened trapezoidal transit template.",
            },
            "dormant_black_hole": {
                "detrend_mode": "adaptive_notch_savgol",
                "harmonic_orders": 3,
                "rationale": "Domain Edit (Gaia Black Hole): Subtract 365.25d annual parallax thermal wave and expand Keplerian search to 3rd harmonic for eccentric periastron wobble.",
            },
            "gw_subthreshold_merger": {
                "detrend_mode": "adaptive_notch_savgol",
                "matched_template_bank": True,
                "rationale": "Domain Edit (GWOSC IMBH): Notch 1.5Hz/3.2Hz scattered-light seismic lines and switch to relativistic inspiral-merger-ringdown chirp template.",
            },
            "anomalous_star": {
                "detrend_mode": "adaptive_notch_savgol",
                "asymmetric_skew_kernel": True,
                "rationale": "Domain Edit (Dipper Star): Remove 29.53d lunar sky-background cycle and match asymmetric fast-ingress / slow-cometary-tail egress kernel.",
            },
        }
        preset = domain_presets.get(domain, domain_presets["exoplanet_transit"])
        llm_out = self.router.complete_json(
            system_prompt="You are the Harness² Domain-Specific Astrophysical Proposer. Output JSON edits.",
            user_prompt=f"Domain={domain}, Diagnostics={report.behavioral_diagnostics}, SNR={report.snr}",
            fallback_payload=preset,
        )
        cand = base.clone(
            new_id=f"{base.domain}-dom-k{step}",
            rationale=llm_out.get("rationale", preset["rationale"]),
        )
        for k_field in ("detrend_mode", "harmonic_orders", "matched_template_bank", "asymmetric_skew_kernel"):
            if k_field in preset:
                cand.scripts["detector_config"][k_field] = llm_out.get(k_field, preset[k_field])
        return cand

    def _compose_from_contrasts(
        self,
        base: HarnessBundle,
        gen: HarnessBundle,
        dom: HarnessBundle,
        base_rep: DetectionReport,
        gen_rep: DetectionReport,
        dom_rep: DetectionReport,
        domain: str,
        step: int,
    ):
        rationale = (
            f"Composed Harness (Step {step}): Combined General Probe's 3.0-sigma flare/glitch clipping "
            f"(reduced RMS to {gen_rep.whitened_residual_rms:.5f}) with Domain Probe's {dom.edit_rationale} "
            f"(boosted SNR from {base_rep.snr} -> {dom_rep.snr})."
        )
        fallback = {"rationale": rationale, "outlier_clip_sigma": 3.0}
        llm_out = self.router.complete_json(
            system_prompt="You are the Harness² Contrastive Composer. Merge the strongest orthogonal edits from General and Domain probes.",
            user_prompt=f"Base SNR={base_rep.snr}, Gen SNR={gen_rep.snr}, Dom SNR={dom_rep.snr}",
            fallback_payload=fallback,
        )
        composed = dom.clone(
            new_id=f"{domain}-composed-k{step}",
            rationale=llm_out.get("rationale", rationale),
        )
        composed.scripts["detector_config"]["outlier_clip_sigma"] = float(llm_out.get("outlier_clip_sigma", 3.0))
        composed.tool_guidance = (
            "1. Clip impulsive flares/glitches at 3.0 MAD sigma. "
            "2. Remove instrumental/stellar periodic background via adaptive notch/Savitzky-Golay filter. "
            "3. Run physics-informed template/harmonic search and verify FAP < 1e-3."
        )
        return composed, composed.edit_rationale
