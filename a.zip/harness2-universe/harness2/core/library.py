"""
Level-2 Harnessing-Level Recursion: Persistent Continual Improvement Library.
Stores adopted harnesses and evidence-supported lessons across tasks and sky sectors.
"""

from dataclasses import dataclass, asdict
from pathlib import Path
from typing import List, Dict, Any
import json
import time


@dataclass
class LessonEntry:
    lesson_id: str
    task_id: str
    domain: str
    component_edited: str
    contrastive_finding: str
    rule_learned: str
    snr_gain: float
    adopted_harness_id: str
    timestamp: float


class ContinualLibrary:
    def __init__(self, storage_path: Path):
        self.storage_path = Path(storage_path)
        self.storage_path.parent.mkdir(parents=True, exist_ok=True)
        self.entries: List[LessonEntry] = []
        if self.storage_path.exists():
            self._load()

    def _load(self):
        raw = json.loads(self.storage_path.read_text(encoding="utf-8"))
        self.entries = [LessonEntry(**item) for item in raw.get("lessons", [])]

    def save(self):
        payload = {
            "updated_at": time.time(),
            "total_lessons": len(self.entries),
            "lessons": [asdict(e) for e in self.entries],
        }
        self.storage_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    def add_lesson(self, entry: LessonEntry):
        self.entries.append(entry)
        self.save()

    def get_domain_lessons(self, domain: str) -> List[LessonEntry]:
        return [e for e in self.entries if e.domain in (domain, "general")]
