"""
Universe Discovery Subsystem for Harness²:
- Public astronomical archive connectors (MAST, NASA Exoplanet Archive, ESA Gaia DR3, LIGO/Virgo/KAGRA GWOSC, ZTF/ALeRCE)
- Physics-based signal detectors (BLS/TLS Exoplanet Transit Search, Astrometric + Microlensing Black Hole Search,
  Matched-Filter Gravitational Wave Sub-Threshold Search, Rare Stellar Anomaly & Dysonian / Debris-Disk Search)
"""
