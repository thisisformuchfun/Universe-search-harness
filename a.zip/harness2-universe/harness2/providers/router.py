"""
Universal AI Provider Router for Harness²-Universe.
Supports:
- OpenRouter (`https://openrouter.ai/api/v1/chat/completions`)
- Local AI APIs (`Ollama`, `vLLM`, `LM Studio`, `llama.cpp` at `http://localhost:11434/v1` or `http://localhost:8000/v1`)
- Any OpenAI-Compatible API (`OpenAI`, `Groq`, `Together`, `DeepSeek`, `Fireworks`)
- Native Anthropic & Google Gemini REST APIs
- Deterministic Offline Physics-Guided Editor (for zero-key testing & reproducible CI)
"""

from dataclasses import dataclass
from typing import Dict, Any, List, Optional
import json
import os
import urllib.request
import urllib.error


@dataclass
class LLMConfig:
    provider: str = "deterministic"  # openrouter | local | openai_compatible | anthropic | gemini | deterministic
    model: str = "google/gemini-2.5-pro"
    base_url: Optional[str] = None
    api_key: Optional[str] = None
    temperature: float = 0.2
    max_tokens: int = 2048

    @classmethod
    def from_env(cls, provider_override: Optional[str] = None, model_override: Optional[str] = None) -> "LLMConfig":
        provider = (provider_override or os.getenv("HARNESS2_PROVIDER", "deterministic")).lower()
        model = model_override or os.getenv("HARNESS2_MODEL", "google/gemini-2.5-pro")

        if provider == "openrouter":
            base_url = os.getenv("OPENROUTER_BASE_URL", "https://openrouter.ai/api/v1")
            api_key = os.getenv("OPENROUTER_API_KEY", "")
        elif provider == "local":
            base_url = os.getenv("LOCAL_AI_BASE_URL", "http://localhost:11434/v1")
            api_key = os.getenv("LOCAL_AI_API_KEY", "ollama")
        elif provider == "openai_compatible":
            base_url = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1")
            api_key = os.getenv("OPENAI_API_KEY", "")
        elif provider == "gemini":
            base_url = "https://generativelanguage.googleapis.com/v1beta"
            api_key = os.getenv("GEMINI_API_KEY", "")
        elif provider == "anthropic":
            base_url = "https://api.anthropic.com/v1"
            api_key = os.getenv("ANTHROPIC_API_KEY", "")
        else:
            base_url = "offline://deterministic"
            api_key = "none"

        return cls(provider=provider, model=model, base_url=base_url, api_key=api_key)


class UniversalModelRouter:
    """Routes Harness² Propose/Compose/Judge prompts to any cloud or local LLM."""

    def __init__(self, config: Optional[LLMConfig] = None):
        self.config = config or LLMConfig.from_env()
        self.call_count = 0

    def complete_json(self, system_prompt: str, user_prompt: str, fallback_payload: Dict[str, Any]) -> Dict[str, Any]:
        self.call_count += 1
        if self.config.provider == "deterministic" or not self.config.api_key:
            return fallback_payload

        try:
            if self.config.provider in ("openrouter", "local", "openai_compatible"):
                return self._call_openai_compatible(system_prompt, user_prompt, fallback_payload)
            elif self.config.provider == "anthropic":
                return self._call_anthropic(system_prompt, user_prompt, fallback_payload)
            elif self.config.provider == "gemini":
                return self._call_gemini(system_prompt, user_prompt, fallback_payload)
        except Exception as exc:
            fallback_payload["_router_note"] = f"Fell back to physics-guided synthesis ({type(exc).__name__})"
            return fallback_payload
        return fallback_payload

    def _call_openai_compatible(self, system_prompt: str, user_prompt: str, fallback: Dict[str, Any]) -> Dict[str, Any]:
        url = f"{self.config.base_url.rstrip('/')}/chat/completions"
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.config.api_key}",
        }
        if self.config.provider == "openrouter":
            headers["HTTP-Referer"] = "https://github.com/google-research/harness2"
            headers["X-Title"] = "Harness2-Universe Discovery Engine"

        body = {
            "model": self.config.model,
            "temperature": self.config.temperature,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            "response_format": {"type": "json_object"},
        }
        req = urllib.request.Request(url, data=json.dumps(body).encode("utf-8"), headers=headers, method="POST")
        with urllib.request.urlopen(req, timeout=45) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            text = data["choices"][0]["message"]["content"]
            return json.loads(text)

    def _call_anthropic(self, system_prompt: str, user_prompt: str, fallback: Dict[str, Any]) -> Dict[str, Any]:
        url = f"{self.config.base_url.rstrip('/')}/messages"
        headers = {
            "Content-Type": "application/json",
            "x-api-key": self.config.api_key,
            "anthropic-version": "2023-06-01",
        }
        body = {
            "model": self.config.model,
            "max_tokens": self.config.max_tokens,
            "system": system_prompt,
            "messages": [{"role": "user", "content": user_prompt + "\nRespond strictly with valid JSON."}],
        }
        req = urllib.request.Request(url, data=json.dumps(body).encode("utf-8"), headers=headers, method="POST")
        with urllib.request.urlopen(req, timeout=45) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            text = data["content"][0]["text"]
            return json.loads(text)

    def _call_gemini(self, system_prompt: str, user_prompt: str, fallback: Dict[str, Any]) -> Dict[str, Any]:
        url = f"{self.config.base_url.rstrip('/')}/models/{self.config.model}:generateContent?key={self.config.api_key}"
        headers = {"Content-Type": "application/json"}
        body = {
            "systemInstruction": {"parts": [{"text": system_prompt}]},
            "contents": [{"parts": [{"text": user_prompt}]}],
            "generationConfig": {"responseMimeType": "application/json", "temperature": self.config.temperature},
        }
        req = urllib.request.Request(url, data=json.dumps(body).encode("utf-8"), headers=headers, method="POST")
        with urllib.request.urlopen(req, timeout=45) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            text = data["candidates"][0]["content"]["parts"][0]["text"]
            return json.loads(text)
