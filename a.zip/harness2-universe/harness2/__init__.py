"""
Harness²-Universe: Recursive Agent Harnessing for an Open Universe.
Built upon https://github.com/google-research/harness2 (Apache-2.0).
"""

__version__ = "0.2.0"
