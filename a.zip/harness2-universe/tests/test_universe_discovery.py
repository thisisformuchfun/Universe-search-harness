import unittest
from pathlib import Path
import tempfile
from harness2.cli.universe import run_universe_sweep


class TestHarness2Universe(unittest.TestCase):
    def test_all_four_cosmic_anomalies_recovered(self):
        with tempfile.TemporaryDirectory() as tmp:
            summary = run_universe_sweep(Path(tmp), k=2, mode="parallel", provider="deterministic")
            self.assertEqual(summary["tasks_completed"], 4)
            self.assertEqual(summary["base_detections"], 0)
            self.assertEqual(summary["refined_detections"], 4)
            self.assertGreater(summary["mean_final_snr"], 11.0)


if __name__ == "__main__":
    unittest.main()
